import os

DIRNAME = os.path.dirname(__file__)
DBFILE  = "test_data.db"
DBPATH  = os.path.join(DIRNAME, DBFILE)