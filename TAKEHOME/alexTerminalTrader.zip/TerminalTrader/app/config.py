import os

DIRNAME = os.path.dirname(__file__)
DBFILE  = 'stock_trader.db'
DBPATH  = os.path.join(DIRNAME, DBFILE)
